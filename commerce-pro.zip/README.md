# Commerce Pro — Plataforma de Aulas

Página única (`index.html`), sem build e sem backend — pode subir direto no GitHub Pages,
Netlify, Vercel ou qualquer hospedagem estática.

## Como publicar no GitHub Pages
1. Crie um repositório novo no GitHub e suba este `index.html` na raiz.
2. Em Settings → Pages, escolha a branch (ex: `main`) e a pasta `/root`.
3. O GitHub gera um link `https://seuusuario.github.io/seurepo/`.

## Como funciona
- Login (sem segurança real): qualquer e-mail + senha `projeto`.
- Modo Admin (switch na sidebar): cria/edita/exclui módulos (com capa) e aulas
  (título, link do YouTube, descrição).
- Tudo fica salvo no `localStorage` do navegador de quem acessa — não há banco de
  dados ainda. Para virar um produto de verdade (login real, progresso por aluno,
  conteúdo centralizado), o próximo passo é levar isso pro Lovable com Supabase.
